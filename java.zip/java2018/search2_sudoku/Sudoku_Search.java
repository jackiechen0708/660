/*
	Sudoku_Search.java
	
	search for Sudoku problems
	doesn't need anything
*/


import Search;
import Search_Node;

import java.util.*;

public class Sudoku_Search extends Search {  

}
    









